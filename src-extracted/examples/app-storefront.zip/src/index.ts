export const feature = "storefront";
export function initialize() { return { feature, ready: true }; }
