# Mejora agente barra · PWR Games

This TypeScript feature sample builds a compact agent bar summary from a supplied game snapshot.
It only validates and formats local data; it does not connect to a service or process payments.

```ts
const summary = buildPwrGamesAgentBar({
  matchId: 'match-01',
  opponent: 'Rockets',
  status: 'live',
  score: { home: 18, away: 14 },
});
```
