import { buildPwrGamesAgentBar } from './pwr-games-agent-bar.js';

const bar = buildPwrGamesAgentBar({
  matchId: 'match-01',
  opponent: 'Rockets',
  status: 'live',
  score: { home: 18, away: 14 },
});

console.log(bar);
