export type PwrGameStatus = 'upcoming' | 'live' | 'finished';

export interface PwrGameSnapshot {
  matchId: string;
  opponent: string;
  status: PwrGameStatus;
  score?: { home: number; away: number };
}

export interface PwrGamesAgentBarSummary {
  matchId: string;
  label: string;
  status: PwrGameStatus;
  scoreText: string;
}

const statusLabels: Record<PwrGameStatus, string> = {
  upcoming: 'Upcoming',
  live: 'Live',
  finished: 'Final',
};

export function buildPwrGamesAgentBar(snapshot: PwrGameSnapshot): PwrGamesAgentBarSummary {
  const matchId = snapshot.matchId.trim();
  const opponent = snapshot.opponent.trim();
  if (!matchId || !opponent) throw new Error('A match ID and opponent are required.');

  const score = snapshot.score;
  if (score && [score.home, score.away].some(value => !Number.isSafeInteger(value) || value < 0)) {
    throw new Error('Game scores must be non-negative whole numbers.');
  }

  return {
    matchId,
    label: `${statusLabels[snapshot.status]} · ${opponent}`,
    status: snapshot.status,
    scoreText: score ? `${score.home}–${score.away}` : '—',
  };
}
