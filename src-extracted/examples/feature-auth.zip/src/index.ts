export const feature = "authentication";
export function initialize() { return { feature, ready: true }; }
