export type AtrStage = 'planned' | 'active' | 'paused' | 'complete';

export interface AtrSystemConfig {
  id: 'atr-sistem';
  name: string;
  stage: AtrStage;
}

const validStages: ReadonlySet<string> = new Set([
  'planned',
  'active',
  'paused',
  'complete',
]);

export function createAtrSystemConfig(input: {
  name: string;
  stage?: AtrStage;
}): AtrSystemConfig {
  const name = input.name.trim();
  if (!name) throw new Error('An ATR system name is required.');

  const stage = input.stage ?? 'planned';
  if (!validStages.has(stage)) throw new Error('Unsupported ATR system stage.');

  return { id: 'atr-sistem', name, stage };
}

export function canRunAtrSystem(config: AtrSystemConfig): boolean {
  return config.stage === 'active';
}
