import { canRunAtrSystem, createAtrSystemConfig } from './atr-sistem.js';

const atrSystem = createAtrSystemConfig({ name: 'Atr Sistem', stage: 'active' });
console.log({ atrSystem, ready: canRunAtrSystem(atrSystem) });
