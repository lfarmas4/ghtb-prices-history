# ATR System sample feature

This small TypeScript package is an uploadable example feature named `atr-sistem`.
It contains a typed configuration helper and a tiny runnable usage example.

The sample is self-contained: it makes no network calls and processes no payments.
The acronym and business rules are intentionally left to the receiving project.

```ts
const config = createAtrSystemConfig({ name: 'Atr Sistem' });
```
