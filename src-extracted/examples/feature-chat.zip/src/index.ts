export const feature = "chat";
export function initialize() { return { feature, ready: true }; }
