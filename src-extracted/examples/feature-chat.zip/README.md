# Chat

Example project archive for testing the CodeWeight file-size quotation flow.
The size-fixture.bin asset supplies a predictable upload weight.
This archive is not a production application.
