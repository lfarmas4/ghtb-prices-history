# CodeWeight

CodeWeight is a static, browser-only interface. Its local deployment and checkout flows are simulations; they make no network calls to deploy software or process real payments. Records are stored in this browser on this device.

The included histories cover 1,194 CrossBox and 340 FitCode mainline commits. Monetary allocations are modeled from commit changes; they are not historical payments.

The ATR System and PWR Games sample archives are fingerprint-recognized at USD 150 and USD 350 by default. Those package rates are configurable. Other files use the configured size-based pricing formula.

Example billing calculation: USD 130 budget, USD 260 usage, USD 130 credit, and USD 130 remaining due. These values illustrate a browser-only calculation, not a payment record.

Deployment and payment history records support soft deletion and restoration.

The source repositories are private. Commit links may require an authorized GitHub account. Do not add credentials or personal data to this package.
