# CodeWeight

This static browser interface stores its records in browser storage on this device.

The included histories cover 1,194 CrossBox and 340 FitCode mainline commits. Monetary allocations are modeled from commit changes; they are not historical payments.

Checkout and payment screens are simulations. No real payments are processed, and no payment credentials should be entered.

The source repositories are private. Commit links may require an authorized GitHub account. Do not add credentials or personal data to this package.
