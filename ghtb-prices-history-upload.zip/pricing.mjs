export const defaultConfig = Object.freeze({ base: 1, perMB: 0.15, includedMB: 0, minimum: 0 });

export function calculateQuote(files, config = defaultConfig) {
  if (!config || ['base', 'perMB', 'includedMB', 'minimum'].some(k => !Number.isFinite(config[k]) || config[k] < 0 || config[k] > 1_000_000)) {
    throw new Error('Invalid pricing configuration');
  }
  if (!Array.isArray(files) || files.some(f => !Number.isSafeInteger(f.size) || f.size < 0)) throw new Error('Invalid file metadata');
  const bytes = files.reduce((sum, f) => sum + f.size, 0);
  if (!Number.isSafeInteger(bytes)) throw new Error('Invalid file total');
  const mb = bytes / 1_000_000;
  const billableMB = Math.max(0, mb - config.includedMB);
  const variable = billableMB * config.perMB;
  const total = files.length ? Math.round(Math.max(config.minimum, config.base + variable) * 100) / 100 : 0;
  return { bytes, mb, billableMB, variable, base: files.length ? config.base : 0, total, count: files.length };
}

export function formatBytes(bytes) {
  if (!bytes) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  const power = Math.min(3, Math.floor(Math.log10(bytes) / 3));
  return `${(bytes / (1000 ** power)).toFixed(power ? 2 : 0)} ${units[power]}`;
}

export const demoBundles = Object.freeze([
  { id: 'auth', name: 'Autenticación', kind: 'Feature', description: 'Login, registro y recuperación de cuenta.', language: 'TypeScript', color: '#3178c6', icon: 'shield', files: [{ name: 'feature-auth.zip', size: 1_200_000, source: 'examples/feature-auth.zip' }] },
  { id: 'chat', name: 'Chat en tiempo real', kind: 'Feature', description: 'Conversaciones, mensajes y notificaciones.', language: 'JavaScript', color: '#f1e05a', icon: 'message', files: [{ name: 'feature-chat.zip', size: 4_800_000, source: 'examples/feature-chat.zip' }] },
  { id: 'store', name: 'Storefront', kind: 'App', description: 'Catálogo, carrito y panel de productos.', language: 'TypeScript', color: '#3178c6', icon: 'repo', files: [{ name: 'app-storefront.zip', size: 18_000_000, source: 'examples/app-storefront.zip' }] }
]);
