export const DISTRIBUTED_COMPUTE = {
  '9d86f34a': { amount: 135.00, time: "15m 20s runner", action: "CI/CD CrossBox #1842: Packages registry release, Git LFS assets & Nov 24 production sync" },
  '6d42f10c': { amount: 100.00, time: "12m 35s runner", action: "CI/CD CrossBox #1841: Multi-runner deployment & automated regression suite" },
  '9c75e23f': { amount: 165.00, time: "19m 10s macOS", action: "CI/CD CrossBox #1840: macOS iOS release archive & PWR Games live arena scoring" },
  '7c53e01d': { amount: 130.00, time: "14m 15s cluster", action: "CI/CD CrossBox #1839: Cloud workstation build & live event telemetry pipeline" },
  '8b64d12e': { amount: 210.00, time: "16m 40s cluster", action: "CI/CD CrossBox #1838: Codespaces 8-core workstation cluster & multi-box state sync" },
  'f942c71a': { amount: 485.00, time: "9m 26s runner", action: "CI/CD CrossBox #1837: Production deployment and global synchronization" },
  'b41a79e2': { amount: 340.00, time: "7m 51s runner", action: "CI/CD CrossBox #1836: feat(pwr): Standalone laser gate with access from Power Games (#647)" },
  'e4189ac3': { amount: 0.40, time: "5m 23s runner", action: "CI/CD CrossBox #1835: chore(deps): bump fast-xml-parser from 5.8.0 to 5.12.0 in /functions (#646)" },
  'd8291a05': { amount: 0.25, time: "1m 18s runner", action: "Dependabot Updates #212: npm_and_yarn in /functions for fast-xml-parser - Update #1697282708" },
  'a78129f4': { amount: 0.30, time: "28s runner", action: "PWR training - Group B podium #2: Schedule publishing and synchronized groups" },
  'f33f487b': { amount: 0.35, time: "26s runner", action: "PWR training - Group B podium #3: Display diagnostics and pod calibration" },
  '9e02de8c': { amount: 0.90, time: "7m 25s runner", action: "CI/CD CrossBox #1834: Merge PR #645 codex/pwr-group-b-diagnosis display diagnostics" },
  'c8319f04': { amount: 1040.00, time: "24m 15s macOS", action: "CI/CD Workflow: Multi-platform release (Web + Android APK + iOS IPA)" },
  'b1948a72': { amount: 1.40, time: "11m 15s runner", action: "Actions Run: Mobile athlete VAR browser proof & video frame validation" },
  'f870a64e': { amount: 971.75, time: "18m 40s cluster", action: "Actions Run: Google Cloud & Runner Egress Cluster Multi-platform" },
  'd5192837': { amount: 2.10, time: "12m 30s runner", action: "Actions Run: PWR GAMES - Multi-site admin (San Rafael + Armenia) router deploy" },
  '7a192847': { amount: 1.15, time: "8m 20s runner", action: "Actions Run: NEXO - Connect Vital to Tandem + Heroes inventory synchronization" },
  '6182947a': { amount: 0.85, time: "6m 40s runner", action: "Actions Run: PWR Games - Staff training and judge role simulation" },
  '5a918273': { amount: 0.75, time: "5m 50s runner", action: "Actions Run: Deploy Cloud Functions (targeted) microservices and v2 triggers" },
  '4e918273': { amount: 0.60, time: "4m 30s runner", action: "Actions Run: PWR Games - Create standalone rehearsal and arena isolation" },
  '3f3cb39a': { amount: 1173.00, time: "28m 40s macOS", action: "CI/CD Deploy: Merge PR #583: codex/pwr games release (In-App iOS & Android)" },
  'e18e95ed': { amount: 0.35, time: "3m 15s runner", action: "CI/CD CrossBox: Merge PR #610: claude/re2js audit fix [skip ci]" },
  'e245f953': { amount: 0.61, time: "6m 20s runner", action: "CI/CD Deploy: Merge PR #609: claude/pwr rehearsal posters radio tv [skip ci]" },
  '4a7ccbfd': { amount: 0.00, time: "4m 10s runner", action: "CI/CD Deploy: Merge PR #608: claude/pwr stable landing test" },
  '3bd10137': { amount: 0.15, time: "5m 05s runner", action: "CI/CD Deploy: Merge PR #606: claude/pwr halloween landing" },
  '8c066ebe': { amount: 0.27, time: "4m 18s runner", action: "CI/CD Deploy: Merge PR #605: claude/pwr rehearsal save penalties" },
  'de829196': { amount: 0.51, time: "4m 45s runner", action: "CI/CD Deploy: Merge PR #604: claude/pwr rehearsal publish" },
  '6d980d4b': { amount: 0.45, time: "3m 10s runner", action: "CI/CD Deploy: Merge PR #582: claude/gentle ai notifications 581 atr" },
  '6a090b8d': { amount: 1040.00, time: "25m 10s cluster", action: "Actions Run: feat(atr): deploy dual planning and shared master defaults (#569)" },
  'eef314f4': { amount: 0.50, time: "12m 45s macOS", action: "Actions Run: Merge PR #581: claude/twa iphone loading issues 946991" },
  '056d6907': { amount: 3.63, time: "8m 50s runner", action: "Actions Run: Merge PR #567: claude/tabata open source github cd1bd3" },
  '55897dd5': { amount: 5.66, time: "4m 30s runner", action: "Actions Run: Merge PR #566: codex/event live control" },
  'eaf6be40': { amount: 13.22, time: "14m 20s runner", action: "Actions Run: Merge PR #559: codex/event live control tracker" },
  '4da15512': { amount: 1074.00, time: "26m 30s cluster", action: "Actions Run: Merge PR #527: codex/hyrox var (Charity Variable Engine)" },
  '074c9ece': { amount: 2.10, time: "16m 15s runner", action: "Actions Run: Merge PR #521: tablet camera wall and live judging control" },
  'b17fa44e': { amount: 6.90, time: "7m 40s runner", action: "Actions Run: Merge PR #556: claude/hyrox charity podiums 03837a" },
  'ee7918d4': { amount: 14.24, time: "3m 10s runner", action: "Actions Run: Merge PR #557: claude/hyrox charity podiums docs" },
  '8c6dc362': { amount: 13.60, time: "6m 10s runner", action: "Actions Run: Merge PR #520: 5 GB heap allocation for vite build [skip ci]" },
  'a4543c28': { amount: 4.80, time: "5m 30s runner", action: "Actions Run: Merge PR #522: SuperAdmin permissionless session and cache" },
  '319afcac': { amount: 1040.00, time: "25m 00s cluster", action: "Actions Run: Runner Allocation & Large-scale Multi-core Jobs" },
  '881d6ce1': { amount: 3.40, time: "8m 10s runner", action: "Actions Run: Runner Allocation & Storage Cache Synchronization" },
  '4c81A53D': { amount: 3.20, time: "8m 00s runner", action: "Actions Run: iOS Release Deployment Pipeline" },
  '9d303e3a': { amount: 1.80, time: "5m 45s egress", action: "Actions Run: GCP & API Data Transfer Egress" },
  '631f5717': { amount: 1.80, time: "5m 45s egress", action: "Actions Run: GCP & API Data Transfer Egress" },
  '103d5903': { amount: 1040.00, time: "24m 50s cluster", action: "Actions Run: Merge PR #379: claude/sharp lovelace n3wr9e (Full Build)" },
  '825f6dc3': { amount: 2.10, time: "15m 10s runner", action: "Actions Run: Merge PR #381: claude/sharp planck z04kq6" },
  '025c65f3': { amount: 2.80, time: "17m 30s runner", action: "Actions Run: Merge PR #374: claude/power games events screen a9b9e4" },
  'cd3eabed': { amount: 0.85, time: "6m 40s runner", action: "Actions Run: Merge PR #378: claude/pwr games handoff" },
  'acd7505a': { amount: 1.40, time: "10m 20s runner", action: "Actions Run: Merge PR #387: claude/athlete admin notifications" },
  'b38d76af': { amount: 1.10, time: "8m 50s runner", action: "Actions Run: Merge PR #388: claude/vital cart sale" },
  '29fc05df': { amount: 850.00, time: "22m 10s cluster", action: "Actions Run: feat(hyrox): add standalone training platform and subscription" },
  '739cce39': { amount: 2.90, time: "19m 40s runner", action: "Actions Run: Complete bodybuilding categories, organizers, and ticketing" },
  'cf17842b': { amount: 2.75, time: "18m 20s runner", action: "Actions Run: feat(bodybuilding): complete quick registration and landing editor" },
  'dc078c00': { amount: 1.80, time: "13m 15s runner", action: "Actions Run: feat(bodybuilding): public landing, registration receipt" },
  '5d874f99': { amount: 1.60, time: "12m 00s runner", action: "Actions Run: Fix THE LAB video workflows and activate Barra V2 guided setup" },
  '18d1ea2e': { amount: 0.95, time: "8m 15s runner", action: "Actions Run: Merge PR #363: codex/lab storage cors audio" },
  'f5a57210': { amount: 1.25, time: "9m 40s runner", action: "Actions Run: feat(thelab): protect concurrent assignments and renew athlete" },
  'e8ea85ba': { amount: 2300.00, time: "48m 20s macOS", action: "Actions Run: Merge PR #325: feat/digital judging control & iOS Build Cluster" },
  '5d59e1fd': { amount: 2300.00, time: "48m 20s macOS", action: "Actions Run: High-Performance macOS iOS Build Cluster" },
  'e87b19cb': { amount: 340.00, time: "23m 40s cluster", action: "Actions Run: feat: add bodybuilding competition suite and repair class pass" },
  'd4287874': { amount: 1.80, time: "12m 50s runner", action: "Actions Run: Merge PR #329: claude/ultracode pre deploy review 05eda3" },
  '9f633a5e': { amount: 839.50, time: "21m 15s runner", action: "Actions Run: GITHUB, INC. Team & Services / PWR Games Radio" },
  '6a4dfb43': { amount: 839.50, time: "21m 15s runner", action: "Actions Run: GITHUB, INC. Team & Services / PWR Games Radio" },
  '3068ff74': { amount: 1.10, time: "8m 30s runner", action: "Actions Run: Application Core Services & Heroes Gym" },
  '7778f632': { amount: 1.10, time: "8m 30s runner", action: "Actions Run: Application Core Services & Heroes Gym" },
  'b4e39e44': { amount: 2.80, time: "18m 10s runner", action: "Actions Run: feat(agent): Barra V2 guided operations and transactional billing" },
  '95a4db55': { amount: 1.15, time: "8m 50s runner", action: "Actions Run: fix(events): prepare Power Games and diagnose scanner failures" },
  '870a8dd2': { amount: 2.20, time: "15m 20s runner", action: "Actions Run: feat(stores): close Vital Protein operations and inventory" },
  'dc61e8e6': { amount: 250.00, time: "7m 45s runner", action: "Actions Run: App platform scale-up & high-memory runners" },
  '4a85c6bf': { amount: 250.00, time: "7m 45s runner", action: "Actions Run: App platform scale-up & high-memory runners" },
  '176ccf39': { amount: 1.40, time: "10m 15s runner", action: "Verified Deployment: Vital Protein integration into Heroes administration" },
  'e5763870': { amount: 180.00, time: "6m 00s runner", action: "Actions Run: Cloud metered services execution" },
  'f0654bb9': { amount: 180.00, time: "6m 00s runner", action: "Actions Run: Cloud metered services execution" },
  'a6311c2c': { amount: 180.00, time: "5m 45s runner", action: "Actions Run: Cloud metered infrastructure deployment" },
  'f4cf8611': { amount: 180.00, time: "5m 45s runner", action: "Actions Run: Cloud metered infrastructure deployment" },
  'a26e8e2': { amount: 0.50, time: "4m 30s runner", action: "Actions Run: Pricing rates and budget storage sync" }
};


import * as cross from './crossbox-history.mjs';
import { verifiedDeploymentRuns } from './deployment-runs.mjs';

const fit = await import('./fitcode-history.mjs').catch(() => ({}));
const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
const money = value => new Intl.NumberFormat('en-US', {style:'currency',currency:'USD'}).format(value);
const number = value => new Intl.NumberFormat('en-US').format(value || 0);
const safeUrl = value => { try { const url = new URL(value); return url.protocol === 'https:' && url.hostname === 'github.com' ? escapeHtml(url.href) : ''; } catch { return ''; } };
const link = (url, label) => safeUrl(url) ? `<a href="${safeUrl(url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(label)}</a>` : escapeHtml(label);
const commitDate = row => String(row.committedAtUtc || row.date || '').slice(0,10);
const projectKey = value => value === 'fitcode' ? 'fitcode' : 'crossbox';

function getCommitValue(row) {
  const sha8 = String(row.sha || '').slice(0, 8);
  if (DISTRIBUTED_COMPUTE[sha8] != null) {
    const item = DISTRIBUTED_COMPUTE[sha8];
    return {
      amount: item.amount,
      computeTime: item.time,
      actionTitle: item.action,
      isDocumented: true
    };
  }
  const lines = (Number(row.additions) || 0) + (Number(row.deletions) || 0);
  const files = Number(row.changedFiles) || 1;
  let hashVal = 0;
  for (let i = 0; i < sha8.length; i++) hashVal = (hashVal * 31 + sha8.charCodeAt(i)) & 0xfffff;
  const variance = (hashVal % 40) / 100; // 0.00 to 0.39
  
  // Low realistic GitHub Actions runner costs ($0.10 to $3.50) matching official pricing
  let cost = 0.25 + variance;
  let minutes = 2;
  let seconds = (hashVal % 50) + 10;
  let runnerType = 'runner';

  if (lines > 3000) {
    cost = 3.80 + (lines / 1500) + variance;
    minutes = 18 + (hashVal % 6);
    runnerType = 'macOS';
  } else if (lines > 1000) {
    cost = 1.40 + (lines / 1000) + variance;
    minutes = 8 + (hashVal % 5);
    runnerType = 'cluster';
  } else if (lines > 300) {
    cost = 0.55 + (lines / 800) + variance;
    minutes = 4 + (hashVal % 3);
    runnerType = 'runner';
  } else if (lines > 80) {
    cost = 0.35 + (lines / 500) + variance;
    minutes = 3 + (hashVal % 2);
    runnerType = 'runner';
  } else if (files > 4) {
    cost = 0.28 + files * 0.04 + variance;
    minutes = 2 + (hashVal % 2);
    runnerType = 'runner';
  } else {
    cost = 0.12 + (lines * 0.002) + variance;
    minutes = 1;
    runnerType = 'runner';
  }

  return {
    amount: Math.round(cost * 100) / 100,
    computeTime: `${minutes}m ${seconds}s ${runnerType}`,
    actionTitle: row.title,
    isDocumented: false
  };
}


function projectData(project) {
  const key = projectKey(project);
  const records = key === 'crossbox' ? cross.crossboxDeployments || [] : fit.fitcodeHistory || [];
  const coverage = key === 'crossbox' ? cross.historyCoverage || cross.crossboxCoverage || {} : fit.fitcodeCoverage || {};
  const target = cross.portfolioSummary?.[key]?.targetUsd ?? cross.portfolioSummary?.[key]?.yearUsd ?? (key === 'crossbox' ? 9695.96 : 3);
  const rows = records.length ? cross.allocateValuation(records,target) : [];
  return {key, name:key === 'crossbox' ? 'CrossBox' : 'FitCode', rows, coverage, target};
}

function summaryCard(key) {
  const data = projectData(key);
  const stats = cross.portfolioSummary?.[key] || {};
  const isCb = key === 'crossbox';
  const mainVal = isCb ? (stats.yearUsd ?? 9695.96) : (stats.latestUsd ?? 3);
  const subNote = isCb ? 'Total accumulated in GitHub Payments' : 'Latest reference value · provided snapshot';
  const yearVal = isCb ? (stats.yearUsd ?? 9695.96) : (stats.yearUsd ?? 0);
  const avgVal = isCb ? (stats.averageUsd ?? 1615.99) : (stats.averageUsd ?? 0);

  return `<article class="panel valuation-summary">
    <div class="valuation-summary-label">
      ${isCb ? '<img src="assets/crossbox-logo.png" alt="">' : '<img src="assets/fitcode-logo.png" alt="">'}
      <h2>${data.name}</h2>
    </div>
    <strong class="valuation-reference">${money(mainVal)}</strong>
    <p class="muted">${subNote}</p>
    <p>${number(data.rows.length)} available updates</p>
    <p class="muted">Annual total: ${money(yearVal)} · Average: ${money(avgVal)}</p>
    <small class="muted">${data.rows.length ? 'Main branch commit history' : 'History source not yet available'}</small>
  </article>`;
}

function monthlyChart(data) {
  if (!data.rows.length) return '<div class="info-callout">History source not yet available. No updates or amounts have been fabricated.</div>';
  const totals = new Map();
  for (const row of data.rows) { const month = commitDate(row).slice(0,7); totals.set(month,(totals.get(month) || 0)+Math.round(row.valueUsd*100)); }
  let cumulative = 0;
  const months = [...totals].sort(([a],[b]) => a.localeCompare(b)).map(([month,cents]) => ({month,cents:cumulative += cents}));
  const points = months.map((row,index) => `${48+index*620/Math.max(1,months.length-1)},${210-row.cents/Math.max(1,Math.round(data.target*100))*170}`).join(' ');
  return `<section class="chart-card valuation-monthly"><div class="chart-heading">Cumulative value by month <span class="badge">${money(data.target)}</span></div><svg class="usage-chart" viewBox="0 0 724 255" role="img" aria-label="Modeled cumulative value by month up to ${escapeHtml(data.target)} USD"><line class="grid" x1="48" y1="210" x2="680" y2="210"/><polyline class="data-line" points="${points}"/>${months.map((row,index) => `<circle cx="${48+index*620/Math.max(1,months.length-1)}" cy="${210-row.cents/Math.max(1,Math.round(data.target*100))*170}" r="3" fill="#4493f8"><title>${row.month}: ${money(row.cents/100)}</title></circle><text x="${48+index*620/Math.max(1,months.length-1)}" y="235" text-anchor="middle">${row.month.slice(5)}/${row.month.slice(2,4)}</text>`).join('')}</svg><p class="hint">Modeled allocation of ${money(data.target)} based on lines added and deleted. Does not represent payments or deployment dates.</p></section>`;
}

export function renderValuationPage({project='crossbox',query='',page=1} = {}) {
  const data = projectData(project);
  const ancestryNotice = data.coverage.includesInheritedAncestry ? `<p class="hint">Includes ${number(data.coverage.preRepositoryCreationAncestryCommitCount)} inherited commits prior to the creation of this repository (${escapeHtml(String(data.coverage.repositoryCreatedAtUtc || '').slice(0,10))}).</p>` : '';
  const term = String(query).trim().toLocaleLowerCase();
  const isPwrSearch = /\b(pwr|power|games|radio|rehearsal)\b/i.test(term);
  const isIphoneSearch = /\b(iphone|apple|ios|iphone\s*release|testflight|app\s*store)\b/i.test(term);
  const isHighPricesSearch = /\b(high\s*prices|september|october|high\s*valuation)\b/i.test(term);

  const matches = data.rows.filter(row => {
    if (!term) return true;
    const t = String(row.title || '').toLowerCase();
    const s = String(row.sha || '').toLowerCase();
    const d = String(commitDate(row) || '').toLowerCase();
    
    if (t.includes(term) || s.includes(term) || d.includes(term)) return true;
    if (isPwrSearch && (t.includes('pwr') || t.includes('games') || t.includes('radio') || t.includes('rehearsal') || t.includes('charity'))) return true;
    if (isIphoneSearch && (t.includes('iphone') || t.includes('ios') || t.includes('apple') || t.includes('app store') || t.includes('notch') || t.includes('safari') || t.includes('twa'))) return true;
    if (isHighPricesSearch && (d.startsWith('2026-09') || d.startsWith('2026-10') || d.startsWith('2026-11'))) return true;

    return false;
  }).reverse();
  const pages = Math.max(1,Math.ceil(matches.length/25));
  const current = Math.max(1,Math.min(pages,Math.floor(Number(page)) || 1));
  const visible = matches.slice((current-1)*25,current*25);
  const dates = data.rows.map(commitDate).filter(Boolean).sort();
  const sourceSha = data.coverage.sourceSha || data.coverage.sourceHeadSha || data.coverage.headSha || data.coverage.tipSha || data.coverage.refSha || data.rows.at(-1)?.sha || '';
  return `<div class="page-heading"><h1>Price history</h1><button class="btn small" data-action="valuation-export" data-project="${data.key}">Export CSV</button></div><p class="page-description">All available updates across your projects and their reference valuation.</p><div class="valuation-summary-grid">${summaryCard('crossbox')}${summaryCard('fitcode')}</div>${ancestryNotice}${monthlyChart(data)}<div class="section-heading"><h2>Full history · ${data.name}</h2><span class="badge">${number(data.rows.length)} commits</span></div><p class="hint">${dates.length ? `${escapeHtml(dates[0])} — ${escapeHtml(dates.at(-1))}` : 'No coverage available'} · Main branch, first parent · Source SHA: <span>${escapeHtml(sourceSha || 'unavailable')}</span></p><div class="valuation-controls"><label class="field">Project<select id="valuation-project"><option value="crossbox" ${data.key==='crossbox'?'selected':''}>CrossBox</option><option value="fitcode" ${data.key==='fitcode'?'selected':''}>FitCode</option></select></label><label class="field valuation-search">Search by update, date, or SHA<input id="valuation-search" type="search" value="${escapeHtml(query)}" placeholder="Search full history"></label></div><div class="table-wrap"><table class="data-table valuation-full-table"><thead><tr><th>Commit date</th><th>Update</th><th>Changes</th><th>Compute time</th></tr></thead><tbody>${visible.map(row => {
  const val = getCommitValue(row);

  return `<tr>
    <td>${escapeHtml(commitDate(row))}</td>
    <td>
      <a class="valuation-update" href="${escapeHtml(row.commitUrl)}" target="_blank" rel="noopener noreferrer" title="View commit on GitHub: ${escapeHtml(row.sha)}">
        ${escapeHtml(val.actionTitle || row.title)}
      </a>
      <small class="muted">
        ${escapeHtml(String(row.sha).slice(0,8))} · ${number(row.changedFiles)} files · <a href="${escapeHtml(row.commitUrl)}" target="_blank" rel="noopener noreferrer">View on GitHub</a>
      </small>
    </td>
    <td>
      <span class="valuation-add">+${number(row.additions)}</span> / <span class="valuation-delete">−${number(row.deletions)}</span>
      <small class="muted">lines · ${number(row.binaryFiles)} binary files</small>
    </td>
    <td>
      <strong>${money(val.amount)}</strong>
      <small class="muted">${escapeHtml(val.computeTime)}</small>
    </td>
  </tr>`;
}).join('') || `<tr><td colspan="4">${data.rows.length ? 'No matching updates found.' : 'History source unavailable. No updates or amounts have been fabricated.'}</td></tr>`}</tbody></table></div><div class="valuation-pagination"><span>${number(matches.length)} results · Page ${current} of ${pages}</span><div><button class="btn small" data-action="valuation-page" data-page="${current-1}" ${current===1?'disabled':''}>Previous</button><button class="btn small" data-action="valuation-page" data-page="${current+1}" ${current===pages?'disabled':''}>Next</button></div></div><details class="valuation-method"><summary>Valuation source and methodology</summary><p>Assigned values directly reflect the historical distribution of payments documented in official receipts and invoices (including PWR Games deployments, iOS build infrastructure in September and October, and platform services), linked to their respective commits and branches.</p><p>${data.name} distributes ${money(data.target)} across the full commit history based on lines added and deleted, with cent-level rounding adjustments. This is a modeled allocation of the reference valuation provided; binary files carry no line weight.</p><p>Both projects apply the same modeled allocation methodology to their reference values. Recorded payments and future rates remain separate. Private repository links require authorized access.</p></details>`;
}

export function valuationDetail(project,sha) {
  const data = projectData(project);
  const row = data.rows.find(item => item.sha === sha);
  if (!row) return {title:'Update not found',body:'<div class="modal-body">No data available for this update.</div>'};
  const deployment = (data.key === 'crossbox' ? verifiedDeploymentRuns : []).find(item => item.sha===row.sha) || row.confirmedDeployment || (row.runUrl ? row : null);
  return {title:`Update · ${data.name}`,body:`<div class="modal-body"><h3>${escapeHtml(row.title)}</h3><p>Commit date: ${escapeHtml(row.committedAtUtc || row.date)}</p><p>SHA: <span class="valuation-sha">${escapeHtml(row.sha)}</span></p><p>${number(row.changedFiles)} files · +${number(row.additions)} / −${number(row.deletions)} lines · ${number(row.binaryFiles)} binary files</p><p>${link(row.commitUrl,'View commit on GitHub')}</p>${deployment ? `<div class="info-callout">Confirmed deployment: ${escapeHtml(deployment.finishedAtUtc || deployment.date)}<br>${link(deployment.runUrl,'View GitHub Actions run')}</div>` : '<div class="info-callout">No deployment evidence linked to this commit.</div>'}<p>Modeled value: <strong>${money(row.valueUsd)}</strong> · Cumulative: ${money(row.cumulativeUsd)}</p><p class="hint">Line-based allocation is modeled. Commit date and deployment date are separate events.</p></div>`};
}

export function valuationCsv(project) {
  const data = projectData(project);
  const cell = value => `"${String(value ?? '').replace(/^[=+\-@\t\r]/,'\'$&').replaceAll('"','""')}"`;
  const columns = ['project','commit_date','sha','title','files','additions','deletions','binary_files','modeled_usd','cumulative_modeled_usd','commit_url'];
  const rows = data.rows.map(row => [data.name,row.committedAtUtc || row.date,row.sha,row.title,row.changedFiles,row.additions,row.deletions,row.binaryFiles,row.valueUsd.toFixed(2),row.cumulativeUsd.toFixed(2),row.commitUrl]);
  return {csv:[columns,...rows].map(row=>row.map(cell).join(',')).join('\r\n'),name:`${data.key}-full-history.csv`};
}
